Instructions to run this program:
1. install Python3
2. put server.py in one computer and client in another.
3. On server machine run: python3 port# file-name p
4. On Client machine run: python3 server-ip server-port# file-name N MSS
5. measure the RTT accordingly